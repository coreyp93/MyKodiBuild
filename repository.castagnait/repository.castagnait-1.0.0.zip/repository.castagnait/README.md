<h2>CastagnaIT Repository for Kodi addons</h2>
<a href="https://github.com/castagnait/repository.castagnait/raw/master/repository.castagnait-1.0.0.zip">Installation link [repository.castagnait-1.0.0.zip]</a><br/>
<hr/>
Content of the repository:
<ol>
  <li><b>plugin.video.netflix</b> - releases</br>
  <hr/>
  Updates published through this channel are only release versions, not daily build.
  For those who prefer to stay up to date with the daily build should do the manual installation, or use other repositories such as Github Notoco "univ repository".
  </li>
</ol>