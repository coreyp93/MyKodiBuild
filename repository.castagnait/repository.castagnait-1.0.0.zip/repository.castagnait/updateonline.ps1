git clone https://github.com/CastagnaIT/plugin.video.netflix.git
python generator.py
Remove-Item -LiteralPath "plugin.video.netflix" -Force -Recurse