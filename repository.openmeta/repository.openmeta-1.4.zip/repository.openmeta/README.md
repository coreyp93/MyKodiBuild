# OpenMeta Repository

The official home of OpenMeta and OpenInfo.

To report bugs or request features, please open an issue on the appropriate GitHub repository for either [OpenMeta](https://www.github.com/drinfernoo/plugin.video.openmeta/) or [OpenInfo](https://www.github.com/drinfernoo/script.extendedinfo/).
