# -*- coding: utf-8 -*-
#
# Copyright (C) 2018 RACC
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
from __future__ import unicode_literals

import sys
from xbmcgui import ListItem
from kodi_six import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from routing import Plugin

import os
import sqlite3
import requests
from requests.exceptions import RequestException
from future.moves.urllib.parse import urlencode

addon = xbmcaddon.Addon()
plugin = Plugin()
plugin.name = addon.getAddonInfo("name")
ADDON_DATA_DIR = xbmc.translatePath(addon.getAddonInfo("path"))
RESOURCES_DIR = os.path.join(ADDON_DATA_DIR, "resources")
DB = os.path.join(RESOURCES_DIR, "livenettv.db")
user_agent = "Dalvik/2.1.0 (Linux; U; Android 5.1; AFTT Build/LMY47O)"


def log(msg, level=xbmc.LOGNOTICE):
    xbmc.log("[{0}] {1}".format(plugin.name, msg), level=level)


@plugin.route("/")
def root():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    live_categories = [dict(row) for row in c.execute("SELECT * FROM live_categories").fetchall()]
    list_items = []
    for c in live_categories:
        li = ListItem(c["catName"])
        url = plugin.url_for(list_channels, cat=c["catId"])
        list_items.append((url, li, True))

    xbmcplugin.addSortMethod(plugin.handle, xbmcplugin.SORT_METHOD_FULLPATH)
    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/list_channels/<cat>")
def list_channels(cat=None):
    list_items = []
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    channel_list = [
        dict(row)
        for row in c.execute(
            "SELECT * FROM live_channels WHERE catId={0} ORDER BY countryId ASC, name ASC".format(
                cat
            )
        ).fetchall()
    ]
    for channel in channel_list:
        title = channel.get("name")
        icon = channel.get("imagePath")
        image = "{0}|{1}".format(icon, urlencode({"User-Agent": user_agent}))
        c_id = channel.get("channelId")

        li = ListItem(title)
        li.setProperty("IsPlayable", "true")
        li.setInfo(type="Video", infoLabels={"Title": title, "mediatype": "video"})
        li.setArt({"thumb": image, "icon": image})
        li.setContentLookup(False)
        url = plugin.url_for(play, c_id=c_id)
        list_items.append((url, li, False))

    xbmcplugin.addDirectoryItems(plugin.handle, list_items)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/play/<c_id>/play.pvr")
def play(c_id):
    stream_server = addon.getSetting("stream_server")
    _url = ""
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    stream_list = [
        dict(row)
        for row in c.execute(
            "SELECT * FROM live_streams WHERE channelId={0}".format(c_id)
        ).fetchall()
    ]
    _channel = [
        dict(row)
        for row in c.execute(
            "SELECT * FROM live_channels WHERE channelId={0}".format(c_id)
        ).fetchall()
    ][0]
    if len(stream_list) > 1:
        select_list = []
        for stream in stream_list:
            select_list.append(stream.get("url"))
        dialog = xbmcgui.Dialog()
        ret = dialog.select("Choose Stream", select_list)
        selected_stream = stream_list[ret]
    else:
        selected_stream = stream_list[0]

    log(repr(selected_stream))
    params = {"url": selected_stream.get("url"), "token": selected_stream.get("token")}
    try:
        r = requests.get(stream_server, params=params, timeout=10)
        _url = r.json()["streamurl"]
        log(repr(_url))
    except RequestException:
        dialog = xbmcgui.Dialog()
        dialog.notification(plugin.name, "Stream server unreachable", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(plugin.handle, False, ListItem())

    if _url:
        stream_headers = urlencode({"User-Agent": "stagefright/1.2 (Linux;Android 5.1.1)"})
        media_url = "{0}|{1}".format(_url, stream_headers)

        title = _channel.get("name")
        icon = _channel.get("imagePath")
        image = "{0}|{1}".format(icon, urlencode({"User-Agent": user_agent}))

        if "playlist.m3u8" in media_url:
            if addon.getSetting("inputstream") == "true":
                li = ListItem(title, path=media_url)
                li.setArt({"thumb": image, "icon": image})
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setProperty("inputstreamaddon", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
                li.setProperty("inputstream.adaptive.stream_headers", stream_headers)
            else:
                li = ListItem(title, path=media_url)
                li.setArt({"thumb": image, "icon": image})
                li.setMimeType("application/vnd.apple.mpegurl")
        else:
            li = ListItem(title, path=media_url)
            li.setArt({"thumb": image, "icon": image})
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(plugin.handle, True, li)


if __name__ == "__main__":
    plugin.run(sys.argv)
