# Aftermath Repository

The official home of the Aftermath Wizard.

Kodi File manager source 
https://drinfernoo.github.io/repository.aftermath/
