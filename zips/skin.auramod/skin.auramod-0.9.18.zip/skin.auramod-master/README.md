# skin.auramod
Skin Mod bringing Titan Bingie, Horizon and Artic Zephyr skin features together in one place.

Credit for the vast majority of code and design goes to the original skin developers, jurialmunkey (Horizon, Artic Zephyr, Aura) and Cartmandos, marduklev (Titan Mod / Bingie).
Visit and support the original skin creators:

https://github.com/cartmandos   https://github.com/jurialmunkey   https://github.com/marduklev
