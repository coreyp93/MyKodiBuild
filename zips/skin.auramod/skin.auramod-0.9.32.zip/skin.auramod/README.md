##Offical Install Instructions##

 Note: Its critical you install the Auramod Repo for Proper dependencys to be met ! 

Go to the Kodi file manager.

Click on "Add source"

The path for the source is https://skyfsza.github.io/repository.auramod/repository.auramod/ (Give it the name "AuraMOD Repo").

Go to "Addons"

In Add-ons, install an addon from zip. When it asks for the location, select "AuraMOD Repo", and install repository.auramod-1.0.1.zip.

Go back to Addons install, but this time, select "Install from repository"

Select the "Auramod Beta Repository"

Go into the "Look and Feel" section in the repo, and you'll find AuraMOD.

​ Make sure to follow the same setup instructions as regular Aura (install Marcelveldt's Repo, setup keys, etc) from the original Aura forum post, in order to get the full set of artwork, ratings, and features.

If you wish to run the Development version of auramod , PLEASE follow the above instructions 
and ONLY after you may then download the zip from this github page and then install from zip in kodi 




This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Icon images from iconmonstr.com see website for license terms
