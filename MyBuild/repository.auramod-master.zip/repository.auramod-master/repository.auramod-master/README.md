# repository.auramod
Kodi repository for beta/test versions of the Auramod Skin
