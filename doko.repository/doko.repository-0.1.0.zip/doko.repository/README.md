# DOKO Repository (Kodi Add-ons)
[Releases](https://github.com/dokoab/doko.repository/releases) (Download the ZIP, install in Kodi)
